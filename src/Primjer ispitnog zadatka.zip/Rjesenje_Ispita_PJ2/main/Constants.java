package main;

public class Constants {
    public static final String KEYBOARD_WAIT = "wait";
    public static final String KEYBOARD_GO = "go";
    public static final String KEYBOARD_END = "end";
}